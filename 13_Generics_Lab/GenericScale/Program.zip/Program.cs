﻿namespace GenericScale
{
    public class StartUp
    {
        public static void Main()
        {
            EqualityScale<int> equality = new EqualityScale<int> (5,5);
            Console.WriteLine(equality.AreEqual());
        }
    }
}